"""Utils for NPR examples.
html2mp3 https://text.npr.org//985359064 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985347984 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985524494 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985032748 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985498425 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985336036 --select ".paragraphs-container" & html2mp3 https://text.npr.org//976385244 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985470204 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985365621 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985296354 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985594759 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985125653 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985290016 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985400141 --select ".paragraphs-container" & html2mp3 https://text.npr.org//984387402 --select ".paragraphs-container" & html2mp3 https://text.npr.org//984614649 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985143101 --select ".paragraphs-container" & html2mp3 https://text.npr.org//982223967 --select ".paragraphs-container" & html2mp3 https://text.npr.org//985421813 --select ".paragraphs-container" & html2mp3 https://text.npr.org//984870694 --select ".paragraphs-container"
"""
import requests
from bs4 import BeautifulSoup  # Alt. html.parser

NPR_URL = "https://text.npr.org"


def get_npr_frontpage_links() -> list[str]:
    r = requests.get(NPR_URL)
    r.raise_for_status()

    soup = BeautifulSoup(r.text)
    s = soup.select("div.topic-container > ul > li > a")

    return [f"https://text.npr.org/{link.attrs['href']}" for link in s]


def npr_sample_call() -> None:
    links = get_npr_frontpage_links()

    script = " \\\\\n\t & ".join(
        [f'html2mp3 url {link} --select ".paragraphs-container"' for link in links]
    )

    print(script)
